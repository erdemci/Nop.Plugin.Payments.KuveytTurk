1. 'Nop.Plugin.Payments.Payrexx' directory contains source code.
2. 'Payments.Payrexx' contains binaries. Just drop it into \Plugins directory on your server.